# 14 Developer Cookbooks

**Project:** RAWPY
**Upstream:** https://github.com/nicedoc/rawpy

Content specific to RAWPY in category CAMERAS.
