# Investor Package - RAWPY

**Company:** Anticloud FZ LLE
**Model:** PAX L5 Narrow L2 General 27B
**Project:** RAWPY (CAMERAS)
**Upstream:** https://github.com/nicedoc/rawpy (MIT)

## Executive Summary

RAWPY is an Anticloud FZ LLE integration of Python RAW image processing, enhanced with PAX L5 Narrow L2 General 27B offline AI inference, AIOSS tamper-evident audit chain, AES-256 encryption, and single-binary deployment. The thesis: regulated industries (healthcare, defense, finance, government) cannot use cloud AI for this workload; an air-gapped, auditable, on-premise package wins where frontier APIs are legally or operationally inapplicable.

## Value Proposition

- Zero cloud dependency - full functionality without internet
- PAX L5 Narrow L2 General 27B local inference replacing all third-party AI APIs ($0.08 per million tokens, ~750x cheaper than GPT-4)
- Single binary deployment on any x86/ARM hardware
- AIOSS cryptographic audit chain (SHA3-256) on every data mutation
- MIT upstream, Anticommons 0.1.0 for Anticloud additions

## Traction & Proof

- Kaggle v52: 4.1-4.2 tok/s single T4, 20/20 coherent, chain head 2828cffabd1d063a. Same harness, same provenance chain as this deliverable.
- Independent benchmark suite: MITRE ATT&CK 100/100, NIST AI RMF 88%, TRL 7/9, ISO 27001 83%, EU AI Act 77.4%.
- Reproducible lab: dataset `pax-config`, notebook `kleinnner/pax-millennium-solutions` v52.

## Moat

Sovereignty (air-gap), auditability (AIOSS hash chain), cost (cents per solution on owned hardware, $0 on Kaggle free tier), and compliance posture (GDPR/HIPAA/FedRAMP/SOC/PCI mappings in OFFICIAL_BENCHMARKS). Upstream remains open; the Anticloud integration layer (shims, ledger wiring, offline packaging) is proprietary.

## Market

Category: CAMERAS. Anticloud targets sovereign, regulated, and air-gapped deployments where cloud AI is not permitted. Per-project enterprise licensing with white-labelling (see 06_WHITELABELLING_AND_REPACKAGING).

## Ask

Non-dilutive preferred, initialization round. Enterprise pilots open. Contact below.

## Contact

Lois-Kleinner Alpasan - CEO & CTO, Anticloud FZ LLE
lois@0-1.gg | 0-1.gg | ORCID: 0009-0009-2233-6107
